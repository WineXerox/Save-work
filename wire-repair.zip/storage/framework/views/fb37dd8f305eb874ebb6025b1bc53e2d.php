<div>
    <?php echo $__env->make('livewire.home.widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.home.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\Users\User\wire-repair\resources\views/livewire/home/index.blade.php ENDPATH**/ ?>