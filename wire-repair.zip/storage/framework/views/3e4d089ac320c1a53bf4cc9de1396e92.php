<div class="d-flex gap-2 mb-3 justify-content-center flex-wrap">
    <a wire:navigate href="<?php echo e(route('work')); ?>" class="btn btn-<?php echo e($route == 'work' ? 'primary' : 'secondary'); ?>">ทั้งหมด</a>
    <a wire:navigate href="<?php echo e(route('work.new')); ?>" class="btn btn-<?php echo e($route == 'work.new' ? 'primary' : 'secondary'); ?>">ใหม่</a>
    <a wire:navigate href="<?php echo e(route('work.proceed')); ?>" class="btn btn-<?php echo e($route == 'work.proceed' ? 'primary' : 'secondary'); ?>">ดำเนินการ</a>
    <a wire:navigate href="<?php echo e(route('work.success')); ?>" class="btn btn-<?php echo e($route == 'work.success' ? 'success' : 'secondary'); ?>">สำเร็จ</a>
    <a wire:navigate href="<?php echo e(route('work.cancel')); ?>" class="btn btn-<?php echo e($route == 'work.cancel' ? 'danger' : 'secondary'); ?>">ยกเลิก</a>
</div>




<?php /**PATH C:\Users\User\wire-repair\resources\views/livewire/work/tab.blade.php ENDPATH**/ ?>