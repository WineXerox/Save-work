<div>
    <?php echo $__env->make('livewire.user.modal-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.user.modal-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <button onclick="backdropRemove()" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCreate">
        เพิ่มผู้ใช้งาน
    </button>

    <?php echo $__env->make('livewire.user.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<?php /**PATH C:\Users\User\wire-repair\resources\views/livewire/user/index.blade.php ENDPATH**/ ?>