<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo e($title ?? 'บันทึกงานซ่อม'); ?></title>

        <link rel="stylesheet" href="<?php echo e(asset('bootstrap-5.3.3/dist/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
        <script src="<?php echo e(asset('jquery/jquery-3.7.1.js')); ?>" ></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <body class="position-relative">
        <?php echo $__env->make('components.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="d-flex">
            <?php echo $__env->make('components.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="container my-3 p-0">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>

        <script src="<?php echo e(asset('bootstrap-5.3.3/dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/global.js')); ?>"></script>
        <script src="<?php echo e(asset('js/swal.js')); ?>"></script>

        <?php echo $__env->yieldContent('script'); ?>
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\Users\User\wire-repair\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>