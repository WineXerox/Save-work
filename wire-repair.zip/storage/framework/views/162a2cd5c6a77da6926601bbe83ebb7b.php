<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo e($title ?? 'บันทึกงานซ่อม'); ?></title>

        <link rel="stylesheet" href="<?php echo e(asset('bootstrap-5.3.3/dist/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
        <script src="<?php echo e(asset('jquery/jquery-3.7.1.js')); ?>" ></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <body>

        <main class="d-flex">
            <div class="container">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('auth.login');

$__html = app('livewire')->mount($__name, $__params, 'lw-1410691286-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </main>

        <script src="<?php echo e(asset('bootstrap-5.3.3/dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/global.js')); ?>"></script>
        <script src="<?php echo e(asset('js/swal.js')); ?>"></script>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\Users\User\wire-repair\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>