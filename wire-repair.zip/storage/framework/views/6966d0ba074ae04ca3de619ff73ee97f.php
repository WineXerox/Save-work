<div>
    <?php echo $__env->make('livewire.work.modal-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.work.tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--[if BLOCK]><![endif]--><?php if(Route::is('work') || Route::is('work.new') || 'livewire.update'): ?>
        <button onclick="backdropRemove()" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCreate">
            เพิ่มงานใหม่
        </button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php echo $__env->make('livewire.work.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
    <script>
        success();
    </script>

    <?php
        session(['success' => false])
    ?>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->




<?php /**PATH C:\Users\User\wire-repair\resources\views/livewire/work/index.blade.php ENDPATH**/ ?>