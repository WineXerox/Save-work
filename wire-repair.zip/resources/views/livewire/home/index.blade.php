<div>
    @include('livewire.home.widget')
    @include('livewire.home.list')
</div>
