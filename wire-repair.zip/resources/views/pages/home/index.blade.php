@extends('components.layouts.app')
@section('content')

    <div class="container">
        @livewire('home.index')
    </div>

@endsection




