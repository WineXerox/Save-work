@extends('components.layouts.app')
@section('content')

    <div class="container">
        @livewire('user.index')
    </div>

@endsection




